#!/bin/bash

mv /home/ubuntu/initial.py /etc/initial.py

mv /home/ubuntu/instructions.py /etc/instructions.py

mv /home/ubuntu/details.txt /etc/details.txt
